# Sociva v1

Android/iOS-ready Expo React Native starter for the Sociva social platform.

## Included now
- Sociva branded onboarding/sign-in UI
- Home feed and stories
- Likes
- Profile section
- Creator wallet section
- Mobile bottom navigation
- Architecture ready for real authentication/database/payment integrations

## Next production integrations
- Supabase/Firebase authentication + database
- Supabase Storage or cloud video/image storage
- Paystack creator tips, platform fees and withdrawals
- Admin moderation/reporting
- Push notifications and messaging
- App Store / Google Play release configuration

## Run locally
Install Node.js, then:
`npm install`
`npx expo start`
Scan the QR code with Expo Go or run on an emulator.
